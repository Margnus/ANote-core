import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path.cwd()
OUT = ROOT / 'build/s2-dense-admission-20261128' / sys.argv[1]
OUT.mkdir(exist_ok=False)
ADB = ['J:/Android/Sdk/platform-tools/adb.exe', '-s', '4628c92']

def run(label, *args, timeout=40):
    r = subprocess.run(ADB + list(args), capture_output=True, timeout=timeout)
    (OUT / (label + '.stdout.txt')).write_bytes(r.stdout)
    (OUT / (label + '.stderr.txt')).write_bytes(r.stderr)
    if r.returncode:
        raise RuntimeError(label + ': ' + r.stderr.decode(errors='replace'))
    return r.stdout

def notes(label):
    names = run(label + '-files', 'shell', 'run-as', 'dev.notecore.preview', 'ls', 'files/preview-notes').decode().splitlines()
    result = {n: hashlib.sha256(run(label + '-' + n, 'exec-out', 'run-as', 'dev.notecore.preview', 'cat', 'files/preview-notes/' + n)).hexdigest() for n in names}
    (OUT / (label + '.json')).write_text(json.dumps(result, indent=2), encoding='utf-8')
    return result

before = notes('notes-before')
fixture = ROOT / '.generated-fixtures/scale/S2-ink-dense-page.bin'
assert hashlib.sha256(fixture.read_bytes()).hexdigest() == '22eea352e0ded47f34cabc0c8b543de0126a658377a6ea286cf60130a17c6725'
run('fixture-push', 'push', str(fixture), '/data/local/tmp/notecore-dense-S2.bin')
run('fixture-copy', 'shell', 'run-as', 'dev.notecore.preview', 'cp', '/data/local/tmp/notecore-dense-S2.bin', 'cache/dense-admission-S2.bin')
run('fixture-sha', 'shell', 'run-as', 'dev.notecore.preview', 'sha256sum', 'cache/dense-admission-S2.bin')
test_apk = ROOT / 'android-app/build/outputs/apk/androidTest/debug/android-app-debug-androidTest.apk'
run('install-test', 'install', '-r', str(test_apk), timeout=60)
for label, package, path in [('app', 'dev.notecore.preview', ROOT/'android-app/build/outputs/apk/debug/android-app-debug.apk'), ('test', 'dev.notecore.preview.test', test_apk)]:
    remote = run(label + '-path', 'shell', 'pm', 'path', package).decode().strip().removeprefix('package:')
    installed = run(label + '-sha', 'shell', 'sha256sum', remote).decode().split()[0]
    assert installed == hashlib.sha256(path.read_bytes()).hexdigest()
    (OUT / (label + '-local-sha256.txt')).write_text(installed, encoding='utf-8')
cmd = ADB + ['shell', 'am', 'instrument', '-w', '-r', '-e', 'notecore_case', 'dense_admission', 'dev.notecore.preview.test/dev.notecore.app.ViewportInstrumentation']
(OUT / 'command.json').write_text(json.dumps(cmd, indent=2), encoding='utf-8')
with (OUT/'instrument.stdout.txt').open('wb') as out, (OUT/'instrument.stderr.txt').open('wb') as err:
    process = subprocess.Popen(cmd, stdout=out, stderr=err)
    time.sleep(3)
    pid = run('pid', 'shell', 'pidof', 'dev.notecore.preview').decode().strip()
    assert pid.isdigit()
    activities = run('activities', 'shell', 'dumpsys', 'activity', 'activities').decode()
    if not any('dev.notecore.preview' in line for line in activities.splitlines() if 'topResumedActivity=' in line):
        run('foreground-launch', 'shell', 'am', 'start', '-W', '-n', 'dev.notecore.preview/dev.notecore.app.MainActivity')
    code = process.wait(timeout=240)
run('app-log', 'logcat', '-d', '--pid='+pid, '-v', 'threadtime', '-s', 'NoteCoreRender', 'NoteCoreStorage', 'NoteCoreTest', 'AndroidRuntime')
data = run('measurements', 'exec-out', 'run-as', 'dev.notecore.preview', 'cat', 'cache/dense-admission.jsonl')
after = notes('notes-after')
assert before == after
output = (OUT/'instrument.stdout.txt').read_text(encoding='utf-8')
result = {'adb_exit_code': code, 'instrumentation_passed': 'dense_admission_status=passed' in output and 'INSTRUMENTATION_CODE: -1' in output,
          'notes_unchanged': True, 'pid': int(pid)}
(OUT/'result.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result, indent=2)); print(output); print(data.decode())
