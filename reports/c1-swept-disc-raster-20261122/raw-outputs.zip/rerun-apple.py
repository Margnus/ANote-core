from pathlib import Path
import json,subprocess,shutil,uuid
root=Path.cwd();out=root/'build/c1-swept-raster-20261122';raw=out/'raw'
def run(label,args,timeout=120,allowed=(0,)):
 r=subprocess.run(list(map(str,args)),capture_output=True,timeout=timeout)
 (raw/(label+'.stdout')).write_bytes(r.stdout);(raw/(label+'.stderr')).write_bytes(r.stderr)
 if r.returncode not in allowed:raise RuntimeError((label,r.returncode,r.stdout[-2000:],r.stderr[-2000:]))
 return r.stdout
shutil.copyfile(root/'tools/probes/swept-disc-raster/AppleRasterProbe.swift',out/'generated/main.swift')
f=out/'artifacts/canvas-core/bin/iosSimulatorArm64/debugFramework'
run('swift-build-top-left',['xcrun','--sdk','iphonesimulator','swiftc','-target','arm64-apple-ios17.0-simulator','-F',f,'-module-cache-path',out/'modules',out/'generated/NativeBrushRenderer.swift',out/'generated/main.swift','-o',out/'apple-probe'])
before=json.loads(run('devices-before-top-left',['xcrun','simctl','list','devices','-j']))
uid=run('create-top-left',['xcrun','simctl','create','NoteCore-Raster-'+uuid.uuid4().hex,'com.apple.CoreSimulator.SimDeviceType.iPhone-18-Pro','com.apple.CoreSimulator.SimRuntime.iOS-27-0']).decode().strip()
try:
 run('boot-top-left',['xcrun','simctl','boot',uid]);run('bootstatus-top-left',['xcrun','simctl','bootstatus',uid,'-b'],180)
 run('apple-probe-top-left',['xcrun','simctl','spawn',uid,out/'apple-probe',out/'apple'])
finally:
 try:run('shutdown-top-left',['xcrun','simctl','shutdown',uid],allowed=(0,1,149))
 finally:run('delete-top-left',['xcrun','simctl','delete',uid])
after=json.loads(run('devices-after-top-left',['xcrun','simctl','list','devices','-j']))
assert before==after
print('Apple top-left redraw completed; temporary device removed')
