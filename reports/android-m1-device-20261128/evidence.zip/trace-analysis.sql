SELECT 'process' AS section, pid, upid, name, start_ts, end_ts
FROM process WHERE name = 'dev.notecore.preview';

SELECT 'app_frames' AS section, COUNT(*) AS frames,
       SUM(dur >= 0) AS completed, SUM(dur < 0) AS unfinished,
       MIN(ts) AS first_ts, MAX(ts + MAX(dur, 0)) AS last_end_ts
FROM actual_frame_timeline_slice
WHERE upid IN (SELECT upid FROM process WHERE pid = 19404 AND name = 'dev.notecore.preview');

SELECT 'frame_types' AS section, layer_name, present_type, jank_type, COUNT(*) AS frames
FROM actual_frame_timeline_slice
WHERE upid IN (SELECT upid FROM process WHERE pid = 19404 AND name = 'dev.notecore.preview')
GROUP BY layer_name, present_type, jank_type;

SELECT 'rss_samples' AS section, COUNT(*) AS samples, MIN(c.ts) AS first_ts, MAX(c.ts) AS last_ts,
       MIN(c.value) AS min_bytes, MAX(c.value) AS max_observed_bytes
FROM counter c JOIN process_counter_track t ON c.track_id = t.id JOIN process p ON p.upid = t.upid
WHERE p.pid = 19404 AND p.name = 'dev.notecore.preview' AND t.name = 'mem.rss';

SELECT 'health' AS section, name, idx, value, severity, source
FROM stats WHERE value != 0 AND (severity != 'info' OR name GLOB '*loss*' OR name GLOB '*overrun*');

SELECT 'buffer_loss' AS section, name, idx, value, severity
FROM stats WHERE name GLOB '*overrun_delta' OR name GLOB '*bytes_overwritten*'
   OR name GLOB '*chunks_discarded*';
