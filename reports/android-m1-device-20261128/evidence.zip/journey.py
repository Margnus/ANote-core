import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
PACKAGE = 'dev.notecore.preview'
ADB = ['adb', '-s', '4628c92']

def adb(*args):
    r = subprocess.run([*ADB, *args], capture_output=True, timeout=40)
    if r.returncode:
        raise RuntimeError(r.stderr.decode(errors='replace'))
    return r.stdout

def tree():
    adb('shell', 'uiautomator', 'dump', '/sdcard/NoteCoreM1Preflight.xml')
    raw = adb('exec-out', 'cat', '/sdcard/NoteCoreM1Preflight.xml')
    (ROOT / 'latest.xml').write_bytes(raw)
    return ET.fromstring(raw)

def wait(**attrs):
    end = time.monotonic() + 25
    while time.monotonic() < end:
        found = next((n for n in tree().iter('node') if n.get('package') == PACKAGE and
                      all(n.get(k) == v for k, v in attrs.items())), None)
        if found is not None:
            return found
    raise AssertionError(attrs)

def tap(node):
    assert node.get('enabled') == 'true'
    x1, y1, x2, y2 = map(int, re.findall(r'\d+', node.get('bounds')))
    assert x2 > x1 and y2 > y1
    adb('shell', 'input', 'tap', str((x1+x2)//2), str((y1+y2)//2))

def click(text):
    tap(wait(text=text))

def count(n):
    return wait(**{'content-desc': f'手写画布，{n}笔'})

def saved(n):
    wait(text=f'已保存到本机 · {n} 笔')

def files():
    return set(adb('shell', 'run-as', PACKAGE, 'ls', 'files/preview-notes').decode().splitlines())

def snapshot(label):
    tree()
    (ROOT / (label + '.xml')).write_bytes((ROOT/'latest.xml').read_bytes())
    (ROOT / (label + '.png')).write_bytes(adb('exec-out', 'screencap', '-p'))

def read_note(name):
    return adb('exec-out', 'run-as', PACKAGE, 'cat', 'files/preview-notes/' + name)

def draw(n):
    node = count(n)
    x1,y1,x2,y2 = map(int,re.findall(r'\d+',node.get('bounds')))
    # In landscape the fitted page is much narrower than the canvas view.
    adb('shell','input','swipe',str((x1+x2)//2-80),str((y1+y2)//2-60),
        str((x1+x2)//2+80),str((y1+y2)//2+60), '400')
    count(n+1)

stage = sys.argv[1]
if stage == 'setup':
    assert not (ROOT/'journey.json').exists(), 'Do not create another note on retry'
    launch = adb('shell','am','start','-W','-n',PACKAGE+'/dev.notecore.app.MainActivity')
    (ROOT/'launch.txt').write_bytes(launch)
    current = tree()
    if any(n.get('text') == '返回' and n.get('package') == PACKAGE for n in current.iter('node')):
        assert any(n.get('text','').startswith('已保存到本机') for n in current.iter('node')), 'Current user note must be confirmed saved'
        click('返回')
    wait(text='新建笔记')
    existing = files()
    existing_hashes = {f: hashlib.sha256(read_note(f)).hexdigest() for f in existing if f.endswith('.ncp')}
    click('新建笔记'); saved(0)
    created = files() - existing
    names = [f for f in created if f.endswith('.ncp')]
    assert len(names) == 1
    state = {'file': names[0], 'before_files': sorted(existing), 'existing_note_sha256': existing_hashes,
             'title': 'M1Preflight20261128'}
    (ROOT/'journey.json').write_text(json.dumps(state,indent=2),encoding='utf-8')
    click('未命名笔记')
    field = wait(**{'class':'android.widget.EditText'})
    tap(field)
    adb('shell','input','keyevent','123')
    adb('shell','input','keyevent',*(['67']*len(field.get('text',''))))
    adb('shell','input','text',state['title']); click('完成'); saved(0)
    snapshot('01-empty')
elif stage == 'exercise':
    state=json.loads((ROOT/'journey.json').read_text(encoding='utf-8'))
    draw(0); saved(1)
    click('撤销'); count(0); saved(0)
    click('重做'); count(1); saved(1)
    tap(wait(**{'content-desc':'笔槽4'}))
    click('荧光笔'); draw(1); saved(2)
    snapshot('02-first-page')
    click('加页'); wait(text='2/2'); count(0)
    draw(0); saved(3)
    snapshot('03-saved')
    data=read_note(state['file'])
    (ROOT/'saved.ncp').write_bytes(data)
    rows=[line.split('\t') for line in data.decode().splitlines()]
    assert sum(r[0]=='G' for r in rows)==2 and sum(r[0]=='S' for r in rows)==3
    state['saved_sha256']=hashlib.sha256(data).hexdigest()
    state['pid_before_restart']=adb('shell','pidof',PACKAGE).decode().strip()
    (ROOT/'journey.json').write_text(json.dumps(state,indent=2),encoding='utf-8')
elif stage == 'trace-retry':
    state=json.loads((ROOT/'journey.json').read_text(encoding='utf-8'))
    assert read_note(state['file']) == (ROOT/'saved.ncp').read_bytes()
    for name in ('saved.ncp', 'reopened.ncp', 'journey.json'):
        (ROOT / ('first-' + name)).write_bytes((ROOT/name).read_bytes())
    wait(text='2/2'); draw(1); saved(4)
    click('撤销'); count(1); saved(3)
    for _ in range(3):
        click('上一页'); wait(text='1/2'); count(2)
        click('下一页'); wait(text='2/2'); count(1)
    data=read_note(state['file'])
    (ROOT/'saved.ncp').write_bytes(data)
    state['saved_sha256']=hashlib.sha256(data).hexdigest()
    state['pid_before_restart']=adb('shell','pidof',PACKAGE).decode().strip()
    state['status']='awaiting-second-reopen'
    (ROOT/'journey.json').write_text(json.dumps(state,indent=2),encoding='utf-8')
elif stage == 'reopen':
    state=json.loads((ROOT/'journey.json').read_text(encoding='utf-8'))
    adb('shell','am','force-stop',PACKAGE)
    (ROOT/'relaunch.txt').write_bytes(adb('shell','am','start','-W','-n',PACKAGE+'/dev.notecore.app.MainActivity'))
    end=time.monotonic()+25
    while time.monotonic()<end:
        node=next((n for n in tree().iter('node') if n.get('package')==PACKAGE and
                   n.get('text','').startswith(state['title']+'\n')),None)
        if node is not None:break
    else:raise AssertionError('Saved note missing from library')
    tap(node); wait(text='1/2'); count(2); wait(text='荧4✓')
    click('下一页'); wait(text='2/2'); count(1)
    data=read_note(state['file'])
    (ROOT/'reopened.ncp').write_bytes(data)
    assert data==(ROOT/'saved.ncp').read_bytes()
    state['pid_after_restart']=adb('shell','pidof',PACKAGE).decode().strip()
    assert state['pid_after_restart'] != state['pid_before_restart']
    state['reopened_sha256']=hashlib.sha256(data).hexdigest()
    state['page_stroke_counts']=[2,1]
    state['input']='ADB synthetic finger swipes on physical hardware; no physical pen input'
    state['status']='passed'
    assert all(hashlib.sha256(read_note(f)).hexdigest() == digest
               for f,digest in state['existing_note_sha256'].items()), 'Existing note changed'
    state['existing_notes_unchanged']=True
    (ROOT/'journey.json').write_text(json.dumps(state,indent=2),encoding='utf-8')
    snapshot('04-reopened')
else:
    raise ValueError(stage)
print(stage+' passed',flush=True)
