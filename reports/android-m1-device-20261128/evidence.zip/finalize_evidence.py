import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parents[2]
RUN = Path(__file__).resolve().parent
OUT = ROOT / 'reports/android-m1-device-20261128'
OUT.mkdir(exist_ok=True)
sys.path.insert(0, str(ROOT/'tools'))
from verify_android_m1_session import verify
from verification_hash import verification_digest

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path):
    return json.loads(path.read_text(encoding='utf-8'))

base = subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
build = load(RUN/'preview-build.json')
bound = build['source_and_build_input_sha256']
source_count = 0
for name, digest in bound.items():
    path = ROOT/name
    assert sha(path) == digest, name
    if '/build/' in name:
        continue
    blob = subprocess.check_output(['git','show',base+':'+name],cwd=ROOT)
    local = path.read_bytes()
    if path.suffix in ('.kt','.kts','.xml','.properties'):
        blob,local=blob.replace(b'\r\n',b'\n'),local.replace(b'\r\n',b'\n')
    assert blob==local, ('product source differs',name)
    source_count += 1
apk=ROOT/'dist/NoteCore-0.1.0-preview.apk'
assert sha(apk) == build['android']['sha256']
session=verify(RUN/'pre3',RUN/'post3',apk,RUN/'trace3/interaction.pftrace')
assert session['status']=='snapshot-pair-verified'
assert load(RUN/'session3.json') == session
for directory in ('trace3','trace-final-tool-probe'):
    receipt=load(RUN/directory/'trace.json')
    digest=sha(RUN/directory/'interaction.pftrace')
    assert receipt['status']=='trace-file-collected' and receipt['trace_sha256']==digest
    assert receipt['remote_removed'] and not receipt['m1_accepted']
    for phase in ('before','after'):
        assert (RUN/directory/f'remote-sha256-{phase}.stdout.txt').read_text(encoding='utf-8').split()==[digest,receipt['remote_path']]
journey=load(RUN/'journey.json')
assert journey['status']=='passed' and journey['existing_notes_unchanged']
assert sha(RUN/'saved.ncp')==sha(RUN/'reopened.ncp')==journey['reopened_sha256']
assert journey['pid_before_restart'] != journey['pid_after_restart']
rows=[r.split('\t') for r in (RUN/'saved.ncp').read_text(encoding='utf-8').splitlines()]
assert sum(r[0]=='G' for r in rows)==2 and sum(r[0]=='S' for r in rows)==3
tests={}
xml=[]
for module,task in [('canvas-core','jvmTest'),('shared-core','jvmTest'),('android-app','testDebugUnitTest')]:
    paths=sorted((ROOT/module/'build/test-results'/task).glob('TEST-*.xml'))
    assert paths
    roots=[ET.parse(p).getroot() for p in paths]
    counts={k:sum(int(x.get(k,0)) for x in roots) for k in ('tests','failures','errors','skipped')}
    assert counts['tests'] > 0 and not any(counts[k] for k in ('failures','errors','skipped'))
    tests[module]=counts
    xml.extend(paths)
issues=ET.parse(RUN/'lint-results-debug.xml').getroot().findall('issue')
assert not any(i.get('severity') in ('Error','Fatal') for i in issues)
for name in ('collector-protocol.json','trace-protocol.json','architecture.json','portable-inputs.json'):
    assert load(RUN/name)['status']=='passed'

tools=['tools/capture_android_m1.py','tools/capture_android_m1_trace.py',
       'tools/verify_android_m1_session.py','tools/verify_android_m1_capture.py','tools/verify_android_m1_trace.py']
# The main recording began before the cleanup exception handler was broadened.
# Preserve that exact source variant and the final variant's separate real-device probe.
record_source=(ROOT/'tools/capture_android_m1_trace.py').read_text(encoding='utf-8').replace(
    'except (OSError, ValueError, RuntimeError) as error:\n            report[\'cleanup_error\']',
    'except RuntimeError as error:\n            report[\'cleanup_error\']')
(RUN/'trace3-collector-source.py').write_text(record_source,encoding='utf-8',newline='\n')
selected=['build.log','initial-build-failure.txt','apksigner.txt','install.txt','install-retry.txt',
          'setup.log','setup-retry.log','setup-fresh-process.log','exercise.log','exercise2.log',
          'reopen.log','reopen-final.log','trace-journey.log','journey.py','journey.json',
          'first-journey.json','saved.ncp','reopened.ncp','first-saved.ncp','first-reopened.ncp',
          '02-first-page.png','03-saved.png','04-reopened.png','04-reopened.xml',
          'android-build-inputs.sha256','preview-build.json','lint-results-debug.xml',
          'collector-protocol.json','trace-protocol.json','architecture.json','portable-inputs.json',
          'trace-overview.stderr.txt','trace-analysis.sql','trace-analysis.csv','trace-analysis.stderr.txt',
          'final-tool-query.csv','final-tool-query.stderr.txt','session3.json','trace3-collector-source.py']
files={name:RUN/name for name in selected if (RUN/name).is_file()}
for directory in ('pre3','post3','trace3','trace-final-tool-probe'):
    files.update({p.relative_to(RUN).as_posix():p for p in (RUN/directory).iterdir() if p.is_file() and p.suffix!='.pftrace'})
files.update({'test-xml/'+p.relative_to(ROOT).as_posix():p for p in xml})
files.update({'verified-tools/'+Path(name).name:ROOT/name for name in tools})
files['finalize_evidence.py']=Path(__file__)
archive=OUT/'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for name,path in sorted(files.items()):z.write(path,name)

mem={}
for phase in ('pre3','post3'):
    text=(RUN/phase/'memory.txt').read_text(encoding='utf-8')
    mem[phase]={key:int(re.search(pattern,text).group(1)) for key,pattern in
               [('pss_kib',r'TOTAL PSS:\s+(\d+)'),('rss_kib',r'TOTAL RSS:\s+(\d+)')]}
report={
    'status':'device-preflight-verified-with-trace-quality-gates-open',
    'app_source_commit':base,'blueprint_commit':'c3cd8fc',
    'product_source_inputs_verified_against_git':source_count,
    'apk':{**build['android'],'signature_v2_verified':True,'installed_digest_verified':True},
    'device':{'model':'23046RP50C','manufacturer':'Xiaomi','api':35,'fingerprint':session['fingerprint'],
              'memtotal_kib':7717864,'inventory_active_display_hz':144.00002,
              'fixed_refresh_rate_measured':False,'usb_charging':True,'battery_percent_at_inventory':76,
              'battery_temperature_celsius_at_inventory':20.2,'orientation_during_journey':'landscape'},
    'tests':tests,'lint_errors':0,'lint_warnings':len(issues),
    'collector_protocol_checks':len(load(RUN/'collector-protocol.json')['checks']),
    'trace_protocol_checks':len(load(RUN/'trace-protocol.json')['checks']),
    'journey':journey,'session':session,'point_memory':mem,
    'trace':{'duration_seconds':120,'bytes':(RUN/'trace3/interaction.pftrace').stat().st_size,
             'sha256':sha(RUN/'trace3/interaction.pftrace'),'transport_device_host_sha256_equal':True,
             'parsed_by':'Perfetto v59.1-1e9c61e98','preview_pid':19404,'app_frame_records':80,
             'completed_frame_records':77,'unfinished_frame_records':3,'rss_samples':241,
             'rss_max_observed_bytes':197054464,'rss_is_total_app_gpu_peak':False,
             'negative_timestamp_records_dropped':14,'ftrace_setup_errors':36,
             'traced_chunks_discarded':3,'buffer_bytes_overwritten':0,
             'complete_loss_free_window_verified':False,
             'main_recording_collector_source_sha256':sha(RUN/'trace3-collector-source.py'),
             'collector_variant_note':'Initial collector before widening cleanup exception handling; final source separately verified by a 5-second device trace and protocol tests.'},
    'failures_retained':['Windows python3 alias exit 9009, retried with PYTHON_BIN',
                         'USB install restriction; user enabled USB installation before retry',
                         'Existing editor/duplicate Activity launch and landscape gesture outside paper; fixture corrected',
                         'ADB input produced a shorter title; actual unique title used, no exact rename acceptance',
                         'Two shell-stdout traces could not be parsed; byte streams contain CRLF expansion, never repaired or used as metric evidence'],
    'adoption':'Adopt file/pull/digest trace transport and shared online/offline metric-process validation. Keep physical runtime evidence limited to this debug candidate and recorded synthetic-finger workflow.',
    'remaining_gates':['Resolve trace health warnings and incomplete frames before performance conclusions',
                       'Physical stylus/pressure/history/cancellation and 60/120 Hz latency recordings',
                       'Full S1/S2/S4/S5/S9, cold/warm repetitions, five-minute loads and memory/trace perturbation controls',
                       '4 GB Android and Pencil iPad, full C1 review and production SQLite approval'],
    'm1_accepted':False,'c1_complete':False,'physical_stylus_verified':False,
    'raw_traces':{'storage':'local only; system traces and unrelated device inventory are not published',
                  'root':str(RUN),'files':{str(p.relative_to(RUN)):sha(p) for p in RUN.rglob('*.pftrace')}},
    'source_sha256':{name:verification_digest(ROOT/name) for name in tools},
    'archive_sha256':sha(archive),'archive_files_sha256':{name:sha(path) for name,path in sorted(files.items())},
}
(OUT/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'status':report['status'],'source_inputs':source_count,'tests':tests,'archive_bytes':archive.stat().st_size},indent=2))
