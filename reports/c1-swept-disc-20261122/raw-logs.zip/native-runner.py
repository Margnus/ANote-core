from pathlib import Path
import json,re,subprocess,uuid,hashlib
root=Path.cwd();out=root/'build/c1-swept-disc-20261122/native-run';out.mkdir(exist_ok=False)
def run(label,args,timeout=60,allowed=(0,)):
 r=subprocess.run(list(map(str,args)),capture_output=True,timeout=timeout)
 (out/(label+'.stdout.log')).write_bytes(r.stdout);(out/(label+'.stderr.log')).write_bytes(r.stderr)
 if r.returncode not in allowed:raise RuntimeError((label,r.returncode,r.stderr[-2000:],r.stdout[-3000:]))
 return r.stdout.decode()
before=json.loads(run('devices-before',['xcrun','simctl','list','devices','-j']))
uid=run('create',['xcrun','simctl','create','NoteCore-Geometry-'+uuid.uuid4().hex,'com.apple.CoreSimulator.SimDeviceType.iPhone-18-Pro','com.apple.CoreSimulator.SimRuntime.iOS-27-0']).strip()
names=['SweptDiscGeometryPocTest','BrushCandidateSeparationTest','BrushEnvelopePocTest','BrushGeometryTest','BrushPathPlanTest']
try:
 run('boot',['xcrun','simctl','boot',uid]);run('bootstatus',['xcrun','simctl','bootstatus',uid,'-b'],180)
 binary=root/'build/c1-swept-disc-20261122/artifacts/canvas-core/bin/iosSimulatorArm64/debugTest/test.kexe'
 output=run('tests',['xcrun','simctl','spawn',uid,binary,'--ktest_filter='+':'.join('dev.notecore.canvas.prototype.'+n+'.*' for n in names),'--ktest_logger=GTEST'],180)
 expected=set()
 for n in names:
  source=root/'canvas-core/src/commonTest/kotlin/dev/notecore/canvas/prototype'/ (n+'.kt')
  expected.update('dev.notecore.canvas.prototype.'+n+'.'+method for method in re.findall(r'@Test\s+fun\s+(\w+)\(',source.read_text()))
 passed=re.findall(r'^\[\s+OK\s+\]\s+(\S+)',output,re.MULTILINE)
 assert len(expected)==38 and len(passed)==38 and set(passed)==expected,output
 summary={'status':'passed','tests':len(passed),'checks':sorted(passed),'device':uid,'runtime':'iOS 27.0 Simulator arm64','binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
 (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
finally:
 try:run('shutdown',['xcrun','simctl','shutdown',uid],allowed=(0,1,149))
 finally:run('delete',['xcrun','simctl','delete',uid])
after=json.loads(run('devices-after',['xcrun','simctl','list','devices','-j']))
assert before==after
print('Native 38 geometry tests passed; temporary simulator deleted; existing device inventory unchanged')
