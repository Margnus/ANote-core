import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path.cwd()
OUT=ROOT/'build/s2-host-android-20261128'/sys.argv[1]
OUT.mkdir(exist_ok=False)
ADB=['J:/Android/Sdk/platform-tools/adb.exe','-s','4628c92']
def run(label,*args,timeout=40):
    r=subprocess.run(ADB+list(args),capture_output=True,timeout=timeout)
    (OUT/(label+'.stdout.txt')).write_bytes(r.stdout)
    (OUT/(label+'.stderr.txt')).write_bytes(r.stderr)
    if r.returncode: raise RuntimeError(label+': '+r.stderr.decode(errors='replace'))
    return r.stdout
def notes(label):
    names=run(label+'-files','shell','run-as','dev.notecore.preview','ls','files/preview-notes').decode().splitlines()
    result={n:hashlib.sha256(run(label+'-'+n,'exec-out','run-as','dev.notecore.preview','cat','files/preview-notes/'+n)).hexdigest() for n in names}
    # Raw note copies stay local, never archive these user files.
    (OUT/(label+'.json')).write_text(json.dumps(result,indent=2),encoding='utf-8')
    return result
before=notes('notes-before')
for label,path,package in [('app',ROOT/'android-app/build/outputs/apk/debug/android-app-debug.apk','dev.notecore.preview'),
                           ('test',ROOT/'android-app/build/outputs/apk/androidTest/debug/android-app-debug-androidTest.apk','dev.notecore.preview.test')]:
    run('install-'+label,'install','-r',str(path),timeout=60)
    remote=run(label+'-path','shell','pm','path',package).decode().strip().removeprefix('package:')
    installed=run(label+'-sha256','shell','sha256sum',remote).decode().split()[0]
    assert installed==hashlib.sha256(path.read_bytes()).hexdigest()
    (OUT/(label+'-local-sha256.txt')).write_text(installed,encoding='utf-8')
cmd=ADB+['shell','am','instrument','-w','-r','-e','notecore_case','surface_frames','dev.notecore.preview.test/dev.notecore.app.ViewportInstrumentation']
(OUT/'command.json').write_text(json.dumps(cmd,indent=2),encoding='utf-8')
with (OUT/'instrument.stdout.txt').open('wb') as out,(OUT/'instrument.stderr.txt').open('wb') as err:
    process=subprocess.Popen(cmd,stdout=out,stderr=err)
    time.sleep(3)
    pid=run('pid','shell','pidof','dev.notecore.preview').decode().strip()
    assert pid.isdigit()
    activities=run('activity-before','shell','dumpsys','activity','activities').decode()
    resumed=[line for line in activities.splitlines() if 'topResumedActivity=' in line]
    if not any('dev.notecore.preview' in line for line in resumed):
        # This vendor blocks the instrumented process's background Activity start.
        # A normal shell foreground launch satisfies its existing Activity waiter.
        run('foreground-launch','shell','am','start','-W','-n','dev.notecore.preview/dev.notecore.app.MainActivity')
    code=process.wait(timeout=180)
run('render-log','logcat','-d','--pid='+pid,'-v','threadtime','-s','NoteCoreRender','NoteCoreStorage','NoteCoreTest','AndroidRuntime')
after=notes('notes-after')
assert after==before
data=(OUT/'instrument.stdout.txt').read_text(encoding='utf-8')
result={'adb_exit_code':code,'instrumentation_passed':'surface_status=passed' in data and 'INSTRUMENTATION_CODE: -1' in data,
        'notes_unchanged':True,'pid':int(pid),'scope':'Original native host instrumentation; no dense S2, real stylus or performance acceptance'}
(OUT/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2));print(data)
