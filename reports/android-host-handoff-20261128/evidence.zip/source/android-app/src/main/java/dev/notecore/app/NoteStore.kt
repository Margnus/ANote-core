package dev.notecore.app

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Log
import dev.notecore.canvas.preview.*
import dev.notecore.canvas.prototype.*
import dev.notecore.document.*
import java.util.UUID
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

internal enum class ExportPickerDisposition { READY, BUSY, CAPACITY, IDENTITY_EXHAUSTED, OWNER_CLOSED, PENDING_RECOVERY }
internal data class ExportPickerAdmission(val disposition: ExportPickerDisposition, val requestCode: Int? = null)
internal enum class ImportPickerDisposition { READY, BUSY, IDENTITY_EXHAUSTED, OWNER_CLOSED }
internal data class ImportPickerAdmission(val disposition: ImportPickerDisposition, val requestCode: Int? = null)
internal enum class StoreOwnerPhase { ACTIVE, RETIRING, RETIRED }
internal enum class StoreRetirementRequest { STARTED, ALREADY_RETIRING, RETIRED, INPUT_PENDING, TRANSFER_PENDING, WORK_PENDING, SAVE_REJECTED }
internal data class StoreRetirementStatus(val phase: StoreOwnerPhase, val pendingWrites: Int,
    val retryRequired: Int, val renderBytes: Long, val workerStopped: Boolean)
internal enum class EditorDeparture { DETACHED, DOCUMENT_CLOSED, RETRY_REQUIRED, STALE }
/** Advisory, read-only, synchronous owner notification. Never a save/content receiver. */
internal fun interface EditorObserver { fun changed() }
internal enum class EditorSavePhase { UNSAVED, SAVING, RETRY_REQUIRED, BACKEND_UNAVAILABLE, WORK_CAPACITY, SAVED, RECOVERY_SAVED, CLOSED }
/** Derived from the original preview file ACK/ledger; never a production DURABLE receipt. */
internal data class EditorPresentation(val documentId: String, val revision: Long, val savedRevision: Long?,
    val pageId: String, val strokeCount: Int, val activeInput: Boolean, val phase: EditorSavePhase)
internal data class EditorAdoption(val notebook: PagedPreviewNotebook?, val failure: PreviewOpenFailure? = null)

data class OpenedDocument(val root: DocumentRoot, val persisted: Boolean, val recovery: PagedPreviewSnapshot = PagedPreviewSnapshot.fromRoot(root))

private sealed interface CatalogReadOutcome {
    data class Complete(val rows: List<NoteSummary>) : CatalogReadOutcome
    data object Capacity : CatalogReadOutcome
}

data class NoteSummary(val id: String, val title: String, val modified: Long)

/** App lifetime storage owner is the main thread. Only immutable captures / exclusive read results cross IO. */
@OptIn(ExperimentalAndroidInkFrame::class)
class NoteStore private constructor(context: Context, private val directory: File = File(context.filesDir, "preview-notes"),
    private val beforeInkCompute: () -> Unit = {}, private val afterInkNativeClose: () -> Unit = {},
    private val afterInkBufferSubmitted: () -> Unit = {}, private val maySettleInkRelease: () -> Boolean = { true },
    private val exportPickerByteLimit: Long = 8L * 1024 * 1024, private val beforeOpenRead: () -> Unit = {},
    private val catalogResultByteLimit: Long = PreviewCatalogBudget.resultByteLimit,
    observeWriteBoundary: ((PreviewWriteBoundary) -> Unit)? = null,
    private val documentBudget: DocumentBudget? = null) {
    init {
        // The fixed main wake route requires this owner before allocating a worker or ledger.
        check(Looper.myLooper() == Looper.getMainLooper()) { "Android Store requires the main owner thread" }
        require(exportPickerByteLimit >= 0) { "Export picker byte limit must be nonnegative" }
        require(catalogResultByteLimit >= 0) { "Catalog result byte limit must be nonnegative" }
    }
    private val io = PreviewFileIO(directory, context.applicationContext.contentResolver, beforeOpenRead, observeWriteBoundary)
    private val main = Handler(Looper.getMainLooper())
    private val wakePending = AtomicBoolean()
    private val executor = BoundedOwnerExecutor(16, STORAGE_WORK_BYTES, "NoteCore-preview-storage", ::requestPump)
    private val ledger = PreviewSaveLedger(ownerCheck = executor::checkOwnerThread)
    private val saveTaskTooLarge = context.getString(R.string.save_task_too_large)
    private data class SaveCallback(val snapshot: PagedPreviewSnapshot, val receive: (Long, String?) -> Unit)
    private val saveCallbacks = mutableMapOf<String, SaveCallback>()
    private var catalogSnapshot: List<NoteSummary> = emptyList()
    internal val catalogRetainedByteCharge: Long get() {
        executor.checkOwnerThread()
        return PreviewCatalogBudget.resultByteCharge(catalogSnapshot.size,
            catalogSnapshot.sumOf { it.id.length.toLong() + it.title.length })
    }
    private var activeNotebook: PagedPreviewNotebook? = null
    // Main-owner presentation identities only. Never retain an Activity or another content authority.
    private val editors = mutableMapOf<String, java.lang.ref.WeakReference<EditorObserver>?>()
    private var notifyingEditors = false
    internal val editorCount: Int get() { executor.checkOwnerThread(); return editors.size }
    private var ownerRetiring = false
    private var ownerRetired = false
    private var ownerStopRequested = false
    private var requestsInFlight = 0
    private var retirementObserver: ((StoreRetirementStatus) -> Unit)? = null
    internal fun ownerRetirementStatus(): StoreRetirementStatus {
        executor.checkOwnerThread()
        val states = ledger.states()
        return StoreRetirementStatus(if (ownerRetired) StoreOwnerPhase.RETIRED else if (ownerRetiring) StoreOwnerPhase.RETIRING else StoreOwnerPhase.ACTIVE,
            states.size, states.count { it.retryRequired }, inkChargedBytes, executor.status().workerStopped)
    }
    internal fun beginOwnerRetirement(onRetired: ((StoreRetirementStatus) -> Unit)? = null): StoreRetirementRequest {
        executor.checkOwnerThread()
        if (ownerRetired) return StoreRetirementRequest.RETIRED
        if (ownerRetiring) return StoreRetirementRequest.ALREADY_RETIRING
        if (editors.isNotEmpty()) return StoreRetirementRequest.WORK_PENDING
        if (activeNotebook?.let { it.hasActiveStroke || it.hasPendingStroke } == true) return StoreRetirementRequest.INPUT_PENDING
        if (pendingExport != null || pendingImport != null) return StoreRetirementRequest.TRANSFER_PENDING
        if (requestsInFlight != 0 || executor.status().entries.any {
            it.stage == OwnedWorkStage.DELIVERING || it.stage == OwnedWorkStage.DELIVERY_BLOCKED
        }) return StoreRetirementRequest.WORK_PENDING
        val note = activeNotebook
        if (note != null && !save(note.capture()) { _, _ -> }) return StoreRetirementRequest.SAVE_REJECTED
        ownerRetiring = true; retirementObserver = onRetired
        if (note != null) releaseActive(note, lostEndpoint = true) else retireInk(lostEndpoint = true)
        inkView.clear()
        advanceOwnerRetirement()
        return StoreRetirementRequest.STARTED
    }
    internal fun retryRetainedWrites(): Boolean {
        executor.checkOwnerThread()
        val worker = executor.status()
        if (ownerRetired || ownerStopRequested || !worker.accepting || worker.entries.any {
            it.stage == OwnedWorkStage.DELIVERING || it.stage == OwnedWorkStage.DELIVERY_BLOCKED
        }) return false
        for (entry in ledger.states().filter { it.retryRequired }) {
            if (ledger.offer(entry.snapshot) != PreviewSaveAdmission.ACCEPTED) return false
        }
        pumpWrites(); publishEditorState(); advanceOwnerRetirement(); return true
    }
    private fun advanceOwnerRetirement() {
        executor.checkOutsideDrain()
        if (!ownerRetiring || ownerRetired) return
        val worker = executor.status()
        if (ledger.states().isNotEmpty() || inkRenderer != null || inkImage != null || worker.entries.isNotEmpty()) return
        if (!ownerStopRequested) { ownerStopRequested = true; executor.stopAccepting() }
        if (!executor.status().isDrained) return
        ownerRetired = true
        catalogSnapshot = emptyList()
        val observer = retirementObserver; retirementObserver = null
        if (observer != null) notifyUi { observer(ownerRetirementStatus()) }
    }
    internal val activeDocumentId: String? get() { executor.checkOwnerThread(); return activeNotebook?.documentId }
    // An identity-only optimization must not retain an obsolete canonical root.
    private var activeSavedRoot = java.lang.ref.WeakReference<DocumentRoot>(null)
    private var activeSavedPending = java.lang.ref.WeakReference<DocumentCommand.Canvas>(null)
    private fun previewBudget(): DocumentBudget = documentBudget ?: checkNotNull(DocumentBudget.validated(
        journalEntries = 4096, journalBytes = 32L * 1024 * 1024, identityBytes = 4L * 1024 * 1024).budget)
    internal fun adopt(opened: OpenedDocument): PagedPreviewNotebook {
        executor.checkOwnerThread()
        check(!ownerRetiring) { "Store owner is retiring" }
        require(opened.root === opened.recovery.root) { "Checkpoint/root mismatch" }
        activeNotebook?.let { check(it.documentId == opened.root.id.value); return it }
        val result = PagedPreviewNotebook.openRecovery(opened.recovery, UUID.randomUUID().toString(),
            previewBudget(),
            executor::checkOwnerThread)
        // This internal entry receives only the reader-validated root and fixed supported budget.
        val note = checkNotNull(result.notebook) { "Unsupported preview adoption: ${result.failure}/${result.documentReason}" }
        activeNotebook = note
        activeSavedRoot = java.lang.ref.WeakReference(opened.root.takeIf { opened.persisted && ledger.latest(note.documentId) == null })
        activeSavedPending = java.lang.ref.WeakReference(opened.recovery.pending.takeIf { opened.persisted && ledger.latest(note.documentId) == null })
        return note
    }
    internal fun create(): PagedPreviewNotebook {
        executor.checkOwnerThread()
        check(!ownerRetiring) { "Store owner is retiring" }
        check(activeNotebook == null) { "Release the previous owner only after snapshot admission" }
        val result = PagedPreviewNotebook.createValidated(UUID.randomUUID().toString(), "未命名笔记", UUID.randomUUID().toString(),
            budget = previewBudget(),
            ownerCheck = executor::checkOwnerThread)
        val note = checkNotNull(result.notebook) { "Unsupported preview creation: ${result.failure}/${result.documentReason}" }
        activeNotebook = note
        activeSavedRoot.clear(); activeSavedPending.clear()
        return note
    }
    internal fun attachActive(note: PagedPreviewNotebook) {
        executor.checkOwnerThread()
        check(!ownerRetiring) { "Store owner is retiring" }
        check(activeNotebook == null || activeNotebook === note) { "Release the previous owner only after snapshot admission" }
        activeNotebook = note
    }
    internal fun attachEditor(note: PagedPreviewNotebook, identity: String, observer: EditorObserver? = null): Boolean {
        executor.checkOwnerThread()
        if (ownerRetiring || identity.isBlank() || identity.length > 64 ||
            (activeNotebook != null && activeNotebook !== note) ||
            (identity !in editors && editors.size >= 8)) return false
        attachActive(note)
        if (observer != null || identity !in editors) editors[identity] = observer?.let { java.lang.ref.WeakReference(it) }
        return true
    }
    internal fun forgetEditor(note: PagedPreviewNotebook, identity: String) {
        executor.checkOwnerThread()
        if (activeNotebook === note) editors.remove(identity)
        // Destruction/recreation is not a request to retire the shared document.
    }
    internal fun leaveEditor(note: PagedPreviewNotebook, identity: String): EditorDeparture {
        executor.checkOwnerThread()
        if (activeNotebook !== note || identity !in editors) return EditorDeparture.STALE
        note.retryPendingStroke()
        if (!saveOwned(note.captureRecovery())) return EditorDeparture.RETRY_REQUIRED
        if (editors.size > 1) { editors.remove(identity); return EditorDeparture.DETACHED }
        if (note.hasActiveStroke) return EditorDeparture.RETRY_REQUIRED
        val observer = editors.remove(identity)
        if (releaseActive(note)) return EditorDeparture.DOCUMENT_CLOSED
        editors[identity] = observer // Pending recovery needs the original confirmed write, not mere admission.
        publishEditorState()
        return EditorDeparture.RETRY_REQUIRED
    }
    internal fun editorPresentation(note: PagedPreviewNotebook): EditorPresentation {
        executor.checkOwnerThread()
        val root = note.snapshot()
        val pending = note.pendingStroke()
        val retained = ledger.states().firstOrNull { it.snapshot.documentId == note.documentId }
        val latest = retained?.snapshot as? PagedPreviewSnapshot
        val worker = executor.status()
        val phase = when {
            activeNotebook !== note || ownerRetired -> EditorSavePhase.CLOSED
            retained != null && (latest == null || latest.root !== root || latest.pending !== pending) -> EditorSavePhase.UNSAVED
            retained?.retryRequired == true -> EditorSavePhase.RETRY_REQUIRED
            retained != null && retained.snapshot.encodingWorkByteCharge > STORAGE_WORK_BYTES -> EditorSavePhase.WORK_CAPACITY
            retained != null && (!worker.accepting || worker.workerFailure != null) -> EditorSavePhase.BACKEND_UNAVAILABLE
            retained != null -> EditorSavePhase.SAVING
            activeSavedRoot.get() === root && activeSavedPending.get() === pending ->
                if (note.hasPendingStroke) EditorSavePhase.RECOVERY_SAVED else EditorSavePhase.SAVED
            else -> EditorSavePhase.UNSAVED
        }
        return EditorPresentation(note.documentId, root.revision, activeSavedRoot.get()?.takeIf { activeNotebook === note && it.id == root.id }?.revision,
            note.currentPageId.value, note.totalStrokeCount, note.hasActiveStroke, phase)
    }
    internal fun presentationChanged(note: PagedPreviewNotebook) {
        executor.checkOwnerThread()
        if (activeNotebook === note) publishEditorState()
    }
    private fun publishEditorState() {
        executor.checkOwnerThread()
        if (notifyingEditors) return // Read-only callbacks; never recurse, spin or enqueue another pump.
        notifyingEditors = true
        try {
            // At most eight weak handles; never copy document/ledger payloads into notifications.
            for ((identity, reference) in editors.toList()) {
                val receiver = reference?.get() ?: continue
                if (editors[identity] !== reference) continue
                notifyUi { receiver.changed() }
            }
        } finally { notifyingEditors = false }
    }
    private fun prepareEditorDocument(id: String?): Boolean {
        executor.checkOwnerThread()
        if (ownerRetiring) return false
        val note = activeNotebook ?: return true
        if (note.documentId == id) return true
        if (editors.isNotEmpty() || note.hasActiveStroke) return false
        return saveOwned(note.captureRecovery()) && releaseActive(note)
    }
    internal fun createForEditor(): PagedPreviewNotebook? = if (prepareEditorDocument(null)) create() else null
    internal fun adoptForEditor(opened: OpenedDocument): EditorAdoption {
        executor.checkOwnerThread()
        if (ownerRetiring || opened.root !== opened.recovery.root) return EditorAdoption(null)
        activeNotebook?.let {
            if (it.documentId == opened.recovery.documentId) return EditorAdoption(it)
            if (editors.isNotEmpty() || it.hasActiveStroke) return EditorAdoption(null)
        }
        previewEditorAdmissionFailure(opened.recovery, previewBudget())?.let { return EditorAdoption(null, it) }
        return EditorAdoption(if (prepareEditorDocument(opened.recovery.documentId)) adopt(opened) else null)
    }
    internal fun releaseActive(note: PagedPreviewNotebook, lostEndpoint: Boolean = false): Boolean {
        executor.checkOwnerThread(); check(activeNotebook === note)
        if (editors.isNotEmpty() || note.hasActiveStroke) return false
        if (note.hasPendingStroke) {
            if (activeSavedRoot.get() !== note.snapshot() || activeSavedPending.get() !== note.pendingStroke() || ledger.latest(note.documentId) != null) return false
            check(note.retireAfterRecovery(note.captureRecovery()))
        } else {
            val root = note.snapshot()
            val retained = ledger.latest(note.documentId) as? PagedPreviewSnapshot
            val durable = retained == null && activeSavedRoot.get() === root && activeSavedPending.get() == null
            val admitted = retained?.root === root && retained?.pending == null
            if (!durable && !admitted) return false
            check(note.retire())
        }
        retireInk(lostEndpoint); activeNotebook = null; activeSavedRoot.clear(); activeSavedPending.clear()
        return true
    }
    // One app-owner capture while the external picker runs. No timeout/Activity destruction release.
    internal val exportPickerSession = UUID.randomUUID().toString()
    internal val importPickerSession: String get() = exportPickerSession
    // Shared non-reusing sequence: late import results cannot collide with later exports.
    private var nextExportRequestCode = 1000
    private var pendingExport: Pair<Int, PagedPreviewSnapshot>? = null
    private var pendingImport: Int? = null
    internal fun beginImportPicker(): ImportPickerAdmission {
        executor.checkOwnerThread()
        if (ownerRetiring) return ImportPickerAdmission(ImportPickerDisposition.OWNER_CLOSED)
        if (pendingImport != null || pendingExport != null) return ImportPickerAdmission(ImportPickerDisposition.BUSY)
        if (nextExportRequestCode > 65535) return ImportPickerAdmission(ImportPickerDisposition.IDENTITY_EXHAUSTED)
        val code = nextExportRequestCode++
        pendingImport = code
        return ImportPickerAdmission(ImportPickerDisposition.READY, code)
    }
    internal fun takeImportPicker(requestCode: Int): Boolean {
        executor.checkOwnerThread()
        if (pendingImport != requestCode) return false
        pendingImport = null
        return true
    }
    internal val exportReservedByteCharge: Long get() {
        executor.checkOwnerThread(); return pendingExport?.second?.retainedByteCharge ?: 0L
    }
    internal fun beginExportPicker(snapshot: PagedPreviewSnapshot): ExportPickerAdmission {
        executor.checkOwnerThread()
        if (ownerRetiring) return ExportPickerAdmission(ExportPickerDisposition.OWNER_CLOSED)
        if (snapshot.pending != null) return ExportPickerAdmission(ExportPickerDisposition.PENDING_RECOVERY)
        if (pendingExport != null || pendingImport != null) return ExportPickerAdmission(ExportPickerDisposition.BUSY)
        if (snapshot.retainedByteCharge > exportPickerByteLimit) return ExportPickerAdmission(ExportPickerDisposition.CAPACITY)
        if (nextExportRequestCode > 65535) return ExportPickerAdmission(ExportPickerDisposition.IDENTITY_EXHAUSTED)
        if (!executor.trySetRetainedOwnerBytes(snapshot.retainedByteCharge)) return ExportPickerAdmission(ExportPickerDisposition.CAPACITY)
        val code = nextExportRequestCode++
        pendingExport = code to snapshot
        return ExportPickerAdmission(ExportPickerDisposition.READY, code)
    }
    /** Mismatched/duplicate results cannot release or substitute another accepted capture. */
    internal fun takeExportPicker(requestCode: Int): PagedPreviewSnapshot? {
        executor.checkOwnerThread()
        val capture = pendingExport?.takeIf { it.first == requestCode } ?: return null
        pendingExport = null
        check(executor.trySetRetainedOwnerBytes(0))
        // Defer save dispatch so the matching picker result can hand its snapshot to export first.
        requestPump()
        return capture.second
    }
    private fun requestPump() {
        if (!wakePending.compareAndSet(false, true)) return
        if (!main.post {
            wakePending.set(false)
            executor.drainResults(16)
            pumpInk()
            pumpWrites()
            advanceOwnerRetirement()
            if (executor.status().entries.firstOrNull()?.stage == OwnedWorkStage.READY) requestPump()
        }) { wakePending.set(false); error("Storage owner event loop unavailable") }
    }
    private data class InkKey(val document: String, val page: String, val revision: Long,
        val surface: String, val width: Int, val height: Int, val x: Double, val y: Double, val scale: Double)
    private var inkRenderer: AndroidInkFrameExperiment? = null
    private var inkImage: AndroidInkFrameExperiment.SurfaceImage? = null
    private var inkPending: AndroidInkFrameExperiment.Request? = null
    private var inkKey: InkKey? = null
    private var inkView = java.lang.ref.WeakReference<InkCanvasView>(null)
    private var inkRetiring = false
    private var inkShown = false
    private var inkGeneration = 0L
    private var inkPollScheduled = false
    private var inkAdmissionRejected = false
    private var observedCallbacks = 0
    internal var inkFramePublications = 0; private set
    internal var inkFrameDraws = 0; private set
    internal var inkReleaseCallbacks = 0; private set
    internal var inkValidFenceObserved = false; private set
    internal var inkHandoffRecovered = false; private set
    internal var inkReleaseDeferred = false; private set
    internal val inkChargedBytes: Long get() = inkRenderer?.chargedBytes ?: 0
    internal val inkOwnerRetained: Boolean get() = inkRenderer != null
    private fun pollInkLater() {
        if (inkPollScheduled) return
        inkPollScheduled = true
        main.postDelayed({ inkPollScheduled = false; requestPump() },16)
    }
    private fun pumpInk() {
        executor.checkOutsideDrain()
        val renderer = inkRenderer ?: return
        if (inkAdmissionRejected) {
            renderer.close()
            check(renderer.isDrained)
            inkRenderer = null; inkKey = null; inkAdmissionRejected = false
            inkView.get()?.invalidate()
            return
        }
        // A lost presentation endpoint must retire on this same owner, including late worker results.
        // Keep the old pool/image charged until their original receipts drain; never create a replacement here.
        if (inkView.get() == null) {
            if (!inkRetiring) retireInk(lostEndpoint = true)
            else inkImage?.closeWithoutView() // Upgrade a prior known on-draw removal on this same image.
        }
        renderer.settleAfterDrain { request, ack ->
            if (request === inkPending) {
                inkPending = null
                val view = inkView.get(); val key = inkKey
                if (!inkRetiring && ack == "PUBLISHED" && view != null && key != null && key == keyFor(view)) {
                    val transform = android.graphics.Matrix().apply {
                        setValues(floatArrayOf(key.scale.toFloat(),0f,(key.x*-key.scale).toFloat(),
                            0f,key.scale.toFloat(),(key.y*-key.scale).toFloat(),0f,0f,1f))
                    }
                    val rect = android.graphics.RectF(key.x.toFloat(),key.y.toFloat(),
                        (key.x+key.width/key.scale).toFloat(),(key.y+key.height/key.scale).toFloat())
                    val page = view.notebook.currentPage
                    inkImage = renderer.prepare(request,view::paintStaticPaper,transform,rect,
                        android.graphics.RectF(0f,0f,page.width.toFloat(),page.height.toFloat()))
                    observedCallbacks = 0
                }
            }
        }
        inkImage?.let { image ->
            image.poll()
            observeInkRelease(image)
            if (image.needsPoll) pollInkLater()
        }
        if (inkRetiring && renderer.isDrained) {
            inkRenderer = null; inkRetiring = false; logInk("owner-drained")
        }
        inkView.get()?.invalidate()
    }
    // Close can settle a receipt synchronously. Record it before dropping the image.
    private fun observeInkRelease(image: AndroidInkFrameExperiment.SurfaceImage) {
        val callbacks = image.callbackCount
        if (callbacks > observedCallbacks) {
            inkReleaseCallbacks += callbacks - observedCallbacks
            observedCallbacks = callbacks
            logInk("release-receipt")
        }
        inkValidFenceObserved = inkValidFenceObserved || image.validFenceObserved
        inkHandoffRecovered = inkHandoffRecovered || image.handoffRecovered
        inkReleaseDeferred = inkReleaseDeferred || image.releaseDeferred
        if (image.released) {
            inkImage = null; inkShown = false
            logInk("source-released")
        }
    }
    private fun logInk(event: String) {
        if (ioDebug) Log.d("NoteCoreRender","$event charged=$inkChargedBytes")
    }
    private val ioDebug = context.applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE != 0
    @android.annotation.TargetApi(33) // Only called after draw's API gate or by its existing renderer pump.
    private fun keyFor(view: InkCanvasView): InkKey? {
        val v = view.viewport; val host = view.surfaceHost ?: return null
        if (activeNotebook !== view.notebook || host.child?.isValid != true || view.width !in 1..4096 || view.height !in 1..4096 ||
            view.width.toLong()*view.height > 4194304 || !v.scale.isFinite() || 1/v.scale !in 0.0001..1e6 ||
            !v.offsetX.isFinite() || !v.offsetY.isFinite()) return null
        return InkKey(view.notebook.documentId,view.notebook.currentPageId.value,view.notebook.changeVersion,
            host.identity,view.width,view.height,-v.offsetX/v.scale,-v.offsetY/v.scale,v.scale)
    }
    @android.annotation.TargetApi(33)
    internal fun drawCommittedInk(view: InkCanvasView, canvas: android.graphics.Canvas): Boolean {
        executor.checkOwnerThread()
        if (ownerRetiring) return false
        if (android.os.Build.VERSION.SDK_INT < 33 || !canvas.isHardwareAccelerated) return false
        val key = keyFor(view) ?: return false
        if (inkView.get() !== view) { retireInk(); inkView = java.lang.ref.WeakReference(view) }
        if (view.needsUnifiedInkComposition) {
            // Removal and the complete Path draw share ViewRoot's on-draw handoff.
            // Render retirement must not cancel the notebook's accepted input.
            if (inkRenderer != null && !inkRetiring) retireInk()
            return false
        }
        if (inkRetiring) return false
        if (inkKey != null && inkKey != key) { retireInk(); return false }
        if (inkRenderer == null) {
            if (inkGeneration == Long.MAX_VALUE) return false
            inkGeneration++
            val scene = view.notebook.snapshot().scene
            val frame = FrameToken(scene.id,scene.revision,inkGeneration,inkGeneration,inkGeneration,inkGeneration)
            inkRenderer = AndroidInkFrameExperiment(frame,view.notebook.currentPage.layerId,executor,::requestPump,
                beforeInkCompute,afterInkNativeClose,afterInkBufferSubmitted,maySettleInkRelease)
            inkKey = key
            inkPending = inkRenderer!!.submit(scene,frame,view.notebook.currentPage.layerId,key.x,key.y,
                key.width,key.height,1/key.scale)
            inkAdmissionRejected = inkPending == null
        }
        val image = inkImage ?: return false
        if (!image.ready) return false
        if (!inkShown) {
            val child = view.surfaceHost?.child ?: return false
            val root = view.rootSurfaceControl ?: return false
            if (!image.schedule(child,root)) { retireInk(); return false }
            inkShown = true; inkFramePublications++
            if (ioDebug) Log.d("NoteCoreRender","frame-scheduled w=${key.width} h=${key.height} charged=$inkChargedBytes backend=surface-control")
        }
        inkFrameDraws++
        return true
    }
    internal fun detachInk(view: InkCanvasView) {
        executor.checkOwnerThread()
        if (inkView.get() === view) retireInk()
    }
    private fun retireInk(lostEndpoint: Boolean = false) {
        executor.checkOwnerThread()
        inkShown = false; inkKey = null; inkPending = null; inkAdmissionRejected = false
        inkImage?.let { image ->
            if (lostEndpoint) image.closeWithoutView() else image.close()
            observeInkRelease(image)
        }
        inkRenderer?.let { it.close(); inkRetiring = true }
        inkView.get()?.invalidate()
        requestPump()
    }
    internal fun reconcileInkRelease(): Boolean {
        executor.checkOutsideDrain()
        val image = inkImage ?: return false
        if (!image.reconcileReleased()) return false
        observeInkRelease(image)
        pumpInk(); advanceOwnerRetirement(); return true
    }
    private fun notifyUi(action: () -> Unit) {
        // Original Notebook/ledger/file keeps responsibility; UI notification is advisory only.
        runCatching(action).onFailure { Log.e("NoteCoreStorage", "UI notification failed after storage handoff", it) }
    }
    fun save(snapshot: PagedPreviewSnapshot, callback: (Long, String?) -> Unit): Boolean = saveSnapshot(snapshot, callback)
    private fun saveOwned(snapshot: PagedPreviewSnapshot): Boolean = saveSnapshot(snapshot, null)
    private fun saveSnapshot(snapshot: PagedPreviewSnapshot, callback: ((Long, String?) -> Unit)?): Boolean {
        executor.checkOwnerThread()
        if (ownerRetiring) {
            if (callback != null) notifyUi { callback(snapshot.version, "当前会话已结束，原内容仍保留") }; return false
        }
        val active = activeNotebook
        // A drained ledger is not a version fence. The live authority still owns the current capture.
        // This does not change already admitted flights or saves retained for inactive documents.
        if (active?.documentId == snapshot.documentId &&
            (snapshot.root !== active.snapshot() || snapshot.pending !== active.pendingStroke())) {
            if (callback != null) notifyUi { callback(snapshot.version, if (active.hasPendingStroke)
                "仍有未提交笔迹，请保留完整恢复记录后重试" else "保存快照已过期，当前笔迹仍保留，请重新保存") }; return false
        }
        if (activeNotebook?.documentId == snapshot.documentId && activeSavedRoot.get() === snapshot.root &&
            activeSavedPending.get() === snapshot.pending && ledger.latest(snapshot.documentId) == null) {
            publishEditorState()
            if (callback != null) notifyUi { callback(snapshot.version, null) }; return true
        }
        val admission = ledger.offer(snapshot)
        if (admission != PreviewSaveAdmission.ACCEPTED) {
            publishEditorState()
            if (callback != null) notifyUi { callback(snapshot.version, if (admission == PreviewSaveAdmission.VERSION_CONFLICT)
                "保存内容发生冲突，请保留当前笔记并导出备份" else "保存队列已满或内容版本过期，请保留当前笔记并重试") }
            return false
        }
        if (callback != null) saveCallbacks[snapshot.documentId] = SaveCallback(ledger.latest(snapshot.documentId) as PagedPreviewSnapshot, callback)
        else if (saveCallbacks[snapshot.documentId]?.snapshot?.sameContent(snapshot) == false) saveCallbacks.remove(snapshot.documentId)
        // Departure has no UI receiver; keep an existing receiver for this exact accepted content.
        pumpWrites()
        publishEditorState()
        return true
    }
    private fun pumpWrites() {
        executor.checkOwnerThread()
        while (true) {
            val worker = executor.status()
            val dispatch = ledger.admitNextWrite(executor.availableBytes(), STORAGE_WORK_BYTES,
                worker.accepting && worker.workerFailure == null)
            val attempt = dispatch.attempt
            if (attempt == null) {
                if (dispatch.disposition != PreviewWriteDisposition.IDLE && dispatch.disposition != PreviewWriteDisposition.BACKPRESSURE) {
                    val ids = if (dispatch.disposition == PreviewWriteDisposition.WORK_CAPACITY)
                        dispatch.documentId?.let(::listOf).orEmpty() else ledger.states()
                            .filter { !it.inFlight && !it.retryRequired }.map { it.snapshot.documentId }
                    // Terminal notification relinquishes only the advisory UI receiver; ledger keeps content.
                    for (id in ids) saveCallbacks.remove(id)?.let { receiver ->
                        notifyUi { receiver.receive(receiver.snapshot.version, if (dispatch.disposition == PreviewWriteDisposition.WORK_CAPACITY)
                            saveTaskTooLarge else "保存后端暂不可用，更改仍保留，请重试") }
                    }
                    publishEditorState()
                }
                return
            }
            val admission = executor.submit(attempt to io, attempt.snapshot.encodingWorkByteCharge, {
                it.second.write(it.first.snapshot); Unit
            }) { input, result ->
                val original = input.first
                val success = result is WorkResult.Succeeded
                check(ledger.complete(original, success))
                if (result is WorkResult.OutcomeUnknown) {
                    Log.e("NoteCoreStorage", "Preview write outcome unknown: ${result.exceptionType}")
                }
                val id = original.snapshot.documentId
                if (success && activeNotebook?.documentId == id) {
                    val captured = original.snapshot as PagedPreviewSnapshot
                    activeSavedRoot = java.lang.ref.WeakReference(captured.root)
                    activeSavedPending = java.lang.ref.WeakReference(captured.pending)
                }
                saveCallbacks[id]?.takeIf { it.snapshot.sameContent(original.snapshot) }?.let { receiver ->
                    saveCallbacks.remove(id)
                    notifyUi { receiver.receive(original.snapshot.version, if (success) null else "保存失败，更改仍在本机会话中，请重试保存") }
                }
                publishEditorState()
                ResultDisposition.ACKNOWLEDGED // Failure content is retained in ledger before ACK.
            }
            if (admission is WorkAdmission.Rejected) {
                check(ledger.returnUnstarted(attempt))
                // Already admitted snapshot stays pending; a completing job wakes and pumps it later.
                if (admission.reason == WorkAdmissionFailure.WORKER_TERMINATED || admission.reason == WorkAdmissionFailure.STOPPED) {
                    val id = attempt.snapshot.documentId
                    saveCallbacks[id]?.takeIf { it.snapshot.sameContent(attempt.snapshot) }?.let { receiver ->
                        saveCallbacks.remove(id)
                        notifyUi { receiver.receive(receiver.snapshot.version, "保存后端暂不可用，更改仍保留，请重试") }
                    }
                }
                return
            }
        }
    }
    private fun <I : Any, R : Any> request(input: I, bytes: Long, compute: (I) -> R,
                                          rejected: () -> Unit, receive: (WorkResult<R>) -> Unit) {
        executor.checkOwnerThread()
        if (ownerRetiring) { notifyUi(rejected); return }
        requestsInFlight++
        val admission = executor.submit(input, bytes, compute) { _, result ->
            requestsInFlight--
            notifyUi { receive(result) }; ResultDisposition.ACKNOWLEDGED
        }
        if (admission is WorkAdmission.Rejected) { requestsInFlight--; notifyUi(rejected) }
    }
    fun export(uri: Uri, snapshot: PagedPreviewSnapshot, callback: (String?) -> Unit) {
        request(Triple(uri, snapshot, io), snapshot.encodingWorkByteCharge, { input ->
            input.third.export(input.first, input.second); Unit
        }, { callback("后台队列繁忙，请重新导出") }) { result ->
            callback(if (result is WorkResult.Succeeded) null else "导出失败，目标文件可能不完整，请重新导出")
        }
    }
    fun importCopy(uri: Uri, callback: (OpenedDocument?, String?) -> Unit) {
        request(uri to io, READ_WORK_BYTES, { input -> input.second.importCopy(input.first) },
            { callback(null, "后台队列繁忙，请重新导入") }) { result ->
            when (result) {
                is WorkResult.Succeeded -> when (val imported = result.value) {
                    is LocalImportResult.Imported -> callback(OpenedDocument(imported.root, true), null)
                    is LocalImportResult.Refused -> callback(null, imported.reason.message)
                }
                else -> callback(null, "导入结果暂无法确认，请先查看列表；已有笔记未覆盖")
            }
        }
    }
    private fun deliverCatalog(disk: List<NoteSummary>, failure: String?, callback: (List<NoteSummary>, String?) -> Unit) {
        executor.checkOwnerThread()
        val retained = retainedSummaries(); val ids = retained.map { it.id }.toSet()
        var rows = retained.size
        var text = retained.sumOf { it.id.length.toLong() + it.title.length }
        var valid = retained.all { it.id.length in 1..128 && it.title.length <= 125 }
        for (row in disk) if (row.id !in ids) {
            rows++; text += row.id.length.toLong() + row.title.length
            valid = valid && row.id.length in 1..128 && row.title.length <= 125
        }
        if (!valid || rows > PreviewCatalogBudget.maxOwnerRows ||
            PreviewCatalogBudget.resultByteCharge(rows, text) > catalogResultByteLimit) {
            callback(catalogSnapshot, "列表超过预览元数据容量，原列表与文件仍保留"); return
        }
        val merged = (disk.filter { it.id !in ids } + retained).sortedByDescending { it.modified }
        catalogSnapshot = java.util.Collections.unmodifiableList(merged)
        callback(catalogSnapshot, failure)
    }
    fun list(callback: (List<NoteSummary>, String?) -> Unit) {
        executor.checkOwnerThread()
        if (ownerRetiring) { callback(catalogSnapshot, "此会话已关闭，请重新打开列表"); return }
        request(io, PreviewCatalogBudget.workByteCharge(directory.path.length), {
            try { CatalogReadOutcome.Complete(it.catalog()) as CatalogReadOutcome }
            catch (_: CatalogCapacityRefusal) { CatalogReadOutcome.Capacity }
        },
            { deliverCatalog(catalogSnapshot, "后台队列繁忙，请重新打开列表", callback) }) { result ->
            // Only a complete successful enumeration may replace the prior owner snapshot.
            when (val outcome = (result as? WorkResult.Succeeded)?.value) {
                is CatalogReadOutcome.Complete -> deliverCatalog(outcome.rows, null, callback)
                CatalogReadOutcome.Capacity -> deliverCatalog(catalogSnapshot, "列表超过预览记录容量，原列表与文件仍保留", callback)
                null -> deliverCatalog(catalogSnapshot, "列表读取失败，原列表与文件仍保留", callback)
            }
        }
    }
    private fun retainedSummaries(): List<NoteSummary> = ledger.states().map {
        NoteSummary(it.snapshot.documentId, it.snapshot.title + "（未保存）", System.currentTimeMillis())
    }
    fun open(id: String, callback: (OpenedDocument?, String?) -> Unit) = open(id, { true }, callback)

    internal fun open(id: String, isRequested: () -> Boolean, callback: (OpenedDocument?, String?) -> Unit) {
        executor.checkOwnerThread()
        if (!isRequested()) return
        if (ownerRetiring || (editors.isNotEmpty() && activeNotebook?.documentId != id)) {
            notifyUi { callback(null, "其他窗口正在编辑，或原笔记尚待保存，请完成后重试") }; return
        }
        if (!isLocalPreviewDocumentId(id)) {
            notifyUi { callback(null, LocalReadFailure.INVALID_LOCAL_IDENTITY.message) }; return
        }
        activeNotebook?.takeIf { it.documentId == id }?.let { callback(OpenedDocument(it.snapshot(), activeSavedRoot.get() === it.snapshot() && activeSavedPending.get() === it.pendingStroke(), it.captureRecovery()), null); return }
        val retained = ledger.latest(id)
        request(Triple(id, retained, io), previewOpenWorkByteCharge(retained), { input ->
            if (input.second == null) input.third.readOutcome(input.first) else input.third.acceptRecovery(input.second as PagedPreviewSnapshot, input.first)
        }, { callback(null, "后台队列繁忙，请重新打开笔记") }) { result ->
            if (!isRequested()) return@request
            val latest = ledger.latest(id)
            // A later same-note write cannot ACK ahead of this read on the serial worker.
            if (ownerRetiring || (latest != null && latest !== retained)) {
                // No mutable/read payload is posted; retry a pure read after this result is ACKed.
                main.post { open(id, isRequested, callback) }
            } else when (result) {
                is WorkResult.Succeeded -> when (val reading = result.value) {
                    is LocalRecoveryRead.Opened -> {
                        // A preceding write may ACK this exact retained snapshot before delivery.
                        val persisted = latest == null
                        callback(OpenedDocument(reading.snapshot.root, persisted, reading.snapshot),
                            if (persisted) null else "有更改尚未保存，请点击保存重试")
                    }
                    is LocalRecoveryRead.Refused -> callback(null, reading.reason.message)
                }
                else -> callback(null, "读取结果暂无法确认，请稍后重试")
            }
        }
    }
    internal fun saveStates(): List<PreviewSaveState> { executor.checkOwnerThread(); return ledger.states() }
    internal fun stopTestBackend() { executor.stopAccepting() }
    companion object {
        private const val STORAGE_WORK_BYTES = 256L * 1024 * 1024
        private val READ_WORK_BYTES = PagedPreviewCodec.maximumDecodingWorkByteCharge() // Declared parsing/UTF/buffer reservation, not measured heap.
        @Volatile private var instance: NoteStore? = null
        fun get(context: Context): NoteStore {
            check(Looper.myLooper() == Looper.getMainLooper()) { "Android Store requires the main owner thread" }
            return instance ?: synchronized(this) {
                instance ?: NoteStore(context.applicationContext).also { instance = it }
            }
        }
        internal fun isolated(context: Context, directory: File, beforeInkCompute: () -> Unit = {},
            afterInkNativeClose: () -> Unit = {}, afterInkBufferSubmitted: () -> Unit = {},
            maySettleInkRelease: () -> Boolean = { true }, exportPickerByteLimit: Long = 8L * 1024 * 1024, beforeOpenRead: () -> Unit = {},
            catalogResultByteLimit: Long = PreviewCatalogBudget.resultByteLimit,
            observeWriteBoundary: ((PreviewWriteBoundary) -> Unit)? = null, documentBudget: DocumentBudget? = null): NoteStore =
            NoteStore(context,directory,beforeInkCompute,afterInkNativeClose,afterInkBufferSubmitted,maySettleInkRelease,exportPickerByteLimit,beforeOpenRead,catalogResultByteLimit,observeWriteBoundary,documentBudget)
    }
}
