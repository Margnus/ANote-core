import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
PACKAGE = 'dev.notecore.preview'
ADB = ['J:/Android/Sdk/platform-tools/adb.exe', '-s', '4628c92']

def adb(*args):
    r = subprocess.run([*ADB, *args], capture_output=True, timeout=40)
    if r.returncode:
        raise RuntimeError(r.stderr.decode(errors='replace'))
    return r.stdout

def tree():
    adb('shell', 'uiautomator', 'dump', '/sdcard/NoteCoreM1Preflight.xml')
    raw = adb('exec-out', 'cat', '/sdcard/NoteCoreM1Preflight.xml')
    (ROOT / 'latest.xml').write_bytes(raw)
    return ET.fromstring(raw)

def wait(**attrs):
    end = time.monotonic() + 25
    while time.monotonic() < end:
        found = next((n for n in tree().iter('node') if n.get('package') == PACKAGE and
                      all(n.get(k) == v for k, v in attrs.items())), None)
        if found is not None:
            return found
    raise AssertionError(attrs)

def tap(node):
    assert node.get('enabled') == 'true'
    x1, y1, x2, y2 = map(int, re.findall(r'\d+', node.get('bounds')))
    assert x2 > x1 and y2 > y1
    adb('shell', 'input', 'tap', str((x1+x2)//2), str((y1+y2)//2))

def click(text):
    tap(wait(text=text))

def count(n):
    return wait(**{'content-desc': f'手写画布，{n}笔'})

def saved(n):
    wait(text=f'已保存到本机 · {n} 笔')

def files():
    return set(adb('shell', 'run-as', PACKAGE, 'ls', 'files/preview-notes').decode().splitlines())

def snapshot(label):
    tree()
    (ROOT / (label + '.xml')).write_bytes((ROOT/'latest.xml').read_bytes())
    (ROOT / (label + '.png')).write_bytes(adb('exec-out', 'screencap', '-p'))

def read_note(name):
    return adb('exec-out', 'run-as', PACKAGE, 'cat', 'files/preview-notes/' + name)

def draw(n):
    node = count(n)
    x1,y1,x2,y2 = map(int,re.findall(r'\d+',node.get('bounds')))
    # In landscape the fitted page is much narrower than the canvas view.
    adb('shell','input','swipe',str((x1+x2)//2-80),str((y1+y2)//2-60),
        str((x1+x2)//2+80),str((y1+y2)//2+60), '400')
    count(n+1)


existing=files()
originals={f:hashlib.sha256(read_note(f)).hexdigest() for f in existing if f.endswith('.ncp')}
if not (ROOT/'launch.txt').exists():
    (ROOT/'launch.txt').write_bytes(adb('shell','am','start','-W','-n',PACKAGE+'/dev.notecore.app.MainActivity'))
wait(text='新建笔记');click('新建笔记');saved(0)
created=[f for f in files()-existing if f.endswith('.ncp')];assert len(created)==1
name=created[0]
click('未命名笔记');field=wait(**{'class':'android.widget.EditText'});tap(field)
adb('shell','input','keyevent','123');adb('shell','input','keyevent',*(['67']*20))
adb('shell','input','text','S2N1128');click('完成');saved(0)
# Use the actual title; exact keyboard text-entry is outside this smoke test.
current=tree();title=next(n.get('text') for n in current.iter('node') if n.get('text','').startswith('S2'))
wait(text='荧光笔✓')
draw(0);saved(1);click('撤销');count(0);saved(0);click('重做');count(1);saved(1)
draw(1);saved(2);snapshot('page-one')
click('加页');wait(text='2/2');count(0);draw(0);saved(3);snapshot('saved')
data=read_note(name);(ROOT/'saved.ncp').write_bytes(data)
pid_before=adb('shell','pidof',PACKAGE).decode().strip()
adb('shell','am','force-stop',PACKAGE)
(ROOT/'relaunch.txt').write_bytes(adb('shell','am','start','-W','-n',PACKAGE+'/dev.notecore.app.MainActivity'))
end=time.monotonic()+25
while time.monotonic()<end:
 node=next((n for n in tree().iter('node') if n.get('package')==PACKAGE and n.get('text','').startswith(title+'\n')),None)
 if node is not None:break
else:raise AssertionError('Saved note missing from library')
tap(node);wait(text='1/2');count(2);click('下一页');wait(text='2/2');count(1);saved(3)
after=read_note(name);assert after==data
pid_after=adb('shell','pidof',PACKAGE).decode().strip();assert pid_before!=pid_after
assert all(hashlib.sha256(read_note(f)).hexdigest()==digest for f,digest in originals.items())
snapshot('reopened')
result={'status':'passed','title':title,'file':name,'sha256':hashlib.sha256(data).hexdigest(),'pid_before':pid_before,'pid_after':pid_after,'page_stroke_counts':[2,1],'existing_note_sha256':originals,'existing_notes_unchanged':True,'input':'ADB synthetic finger; selected highlighter; no physical stylus or latency acceptance'}
(ROOT/'verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
