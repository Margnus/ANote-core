import concurrent.futures
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ROOT = Path.cwd()
OUT = ROOT/'build/m1-trace-quality-20261128'
sys.path.insert(0,str(ROOT/'tools'))
import capture_android_m1_trace as original
ADB = ['J:/Android/Sdk/platform-tools/adb.exe','-s','4628c92']
def adb(*args):
    return subprocess.run([*ADB,*args],check=True,capture_output=True,timeout=30).stdout
def tree(label):
    adb('shell','uiautomator','dump','/sdcard/NoteCoreTraceQuality.xml')
    data=adb('exec-out','cat','/sdcard/NoteCoreTraceQuality.xml')
    (OUT/(label+'.xml')).write_bytes(data)
    root=ET.fromstring(data)
    assert any(n.get('text')=='M1P20261128' for n in root.iter('node'))
    assert any(n.get('text')=='已保存到本机 · 3 笔' for n in root.iter('node'))
    return root
def files():
    names=adb('shell','run-as','dev.notecore.preview','ls','files/preview-notes').decode().splitlines()
    return {n:hashlib.sha256(adb('exec-out','run-as','dev.notecore.preview','cat','files/preview-notes/'+n)).hexdigest() for n in names if n.endswith('.ncp')}
def snapshot(path):
    subprocess.run([sys.executable,'tools/capture_android_m1.py','--adb',ADB[0],'--serial','4628c92','--apk','dist/NoteCore-0.1.0-preview.apk','--output',str(path)],check=True,stdout=subprocess.DEVNULL)

variant=OUT/'stream-tool'
(variant/'probes').mkdir(parents=True,exist_ok=False)
shutil.copy2(ROOT/'tools/capture_android_m1_trace.py',variant/'capture_android_m1_trace.py')
config=(ROOT/'tools/probes/m1-android-perfetto.pbtxt').read_bytes()+b'\nwrite_into_file: true\nfile_write_period_ms: 1000\nbuiltin_data_sources { snapshot_interval_ms: 1000 }\n'
(variant/'probes/m1-android-perfetto.pbtxt').write_bytes(config.replace(b'      atrace_categories: "gfx"\n',b'').replace(b'      atrace_categories: "gfx"\r\n',b''))
spec=importlib.util.spec_from_file_location('diagnostic',variant/'capture_android_m1_trace.py')
diagnostic=importlib.util.module_from_spec(spec);spec.loader.exec_module(diagnostic)
before=files()
tree('stream-before')
evidence={'scope':'One 20s periodic-write diagnostic page-flip window; synthetic finger; stock refresh; no performance acceptance','before_note_sha256':before,'runs':[]}
(OUT/'stream-start.json').write_text(json.dumps(evidence,indent=2),encoding='utf-8')
for name,collector in [('stream-no-gfx',diagnostic)]:
    run=OUT/name
    snapshot(run/'pre')
    actions=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
        future=pool.submit(collector.capture,ADB[0],'4628c92',run/'trace',20)
        time.sleep(3)
        for x in [110,390,110,390]:
            adb('shell','input','tap',str(x),'780')
            actions.append({'monotonic':time.monotonic(),'x':x,'y':780})
            time.sleep(3)
        receipt=future.result()
    snapshot(run/'post')
    tree(name+'-after')
    after=files()
    evidence['runs'].append({'name':name,'actions':actions,'trace_sha256':receipt['trace_sha256'],'notes_unchanged':after==before})
    (OUT/'stream-comparison.json').write_text(json.dumps(evidence,indent=2),encoding='utf-8')
    assert after==before
    print(name,receipt['trace_sha256'],flush=True)
