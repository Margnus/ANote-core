SELECT surface_frame_token,ts,dur FROM actual_frame_timeline_slice WHERE upid IN (SELECT upid FROM process WHERE pid=19404 AND name='dev.notecore.preview');
