SELECT name,idx,value,severity,source FROM stats;
